
package com.taqwimi.reminder.engine
import com.taqwimi.reminder.data.EndType
import com.taqwimi.reminder.data.Reminder
import com.taqwimi.reminder.data.RepeatUnit
import java.time.*
object RecurrenceEngine {
    fun generateOccurrences(reminder: Reminder, from: LocalDate = LocalDate.now(), limit: Int = 100): List<LocalDateTime> {
        if (!reminder.repeatEnabled) {
            val dt = millisToLdt(reminder.startDateTimeMillis)
            return if (dt.toLocalDate() >= from) listOf(dt) else emptyList()
        }
        val start = millisToLdt(reminder.startDateTimeMillis)
        val occurrences = mutableListOf<LocalDateTime>()
        var current = start
        var count = 0
        while (occurrences.size < limit) {
            if (current.toLocalDate() >= from) {
                if (reminder.endType == EndType.UNTIL_DATE) {
                    val end = reminder.endDateMillis?.let { millisToLdt(it) }
                    if (end != null && current.isAfter(end)) break
                }
                if (reminder.endType == EndType.AFTER_COUNT) {
                    if (count >= (reminder.endCount ?: Int.MAX_VALUE)) break
                }
                occurrences.add(current)
            }
            current = when (reminder.repeatUnit) {
                RepeatUnit.DAY -> current.plusDays(reminder.repeatInterval.toLong())
                RepeatUnit.WEEK -> current.plusWeeks(reminder.repeatInterval.toLong())
                RepeatUnit.MONTH -> current.plusMonths(reminder.repeatInterval.toLong())
                RepeatUnit.YEAR -> current.plusYears(reminder.repeatInterval.toLong())
            }
            count++
            if (count > 10000) break
        }
        return occurrences
    }
    fun nextOccurrence(reminder: Reminder, afterMillis: Long = System.currentTimeMillis()): LocalDateTime? {
        val after = millisToLdt(afterMillis).toLocalDate()
        return generateOccurrences(reminder, from = after, limit = 1).firstOrNull()
    }
    private fun millisToLdt(millis: Long): LocalDateTime {
        return LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(millis), java.time.ZoneId.systemDefault())
    }
}
