
package com.taqwimi.reminder.notifications
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.taqwimi.reminder.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            CoroutineScope(Dispatchers.IO).launch {
                val active = AppDatabase.get(context).reminderDao().getActive()
                active.forEach { AlarmScheduler.schedule(context, it) }
            }
        }
    }
}
