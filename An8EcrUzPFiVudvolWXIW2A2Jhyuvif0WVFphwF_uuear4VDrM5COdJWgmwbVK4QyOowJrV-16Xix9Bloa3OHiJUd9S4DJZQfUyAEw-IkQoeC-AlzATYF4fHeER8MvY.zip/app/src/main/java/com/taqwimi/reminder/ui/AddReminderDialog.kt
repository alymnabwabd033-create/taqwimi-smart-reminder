
package com.taqwimi.reminder.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.taqwimi.reminder.data.*
@Composable
fun AddReminderDialog(onDismiss: () -> Unit, onSave: (Reminder) -> Unit) {
    var title by remember { mutableStateOf("") }
    var intervalText by remember { mutableStateOf("10") }
    var unit by remember { mutableStateOf(RepeatUnit.DAY) }
    var repeatEnabled by remember { mutableStateOf(true) }
    var endType by remember { mutableStateOf(EndType.NEVER) }
    var endCountText by remember { mutableStateOf("10") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة تذكير") },
        text = {
            Column {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("اسم التذكير") })
                Row { Checkbox(checked = repeatEnabled, onCheckedChange = { repeatEnabled = it }); Text("تكرار حر") }
                if (repeatEnabled) {
                    OutlinedTextField(value = intervalText, onValueChange = { intervalText = it }, label = { Text("كل كم؟ مثلا 1,5,10,30,60,90") })
                    Row { RepeatUnit.values().forEach { u -> FilterChip(selected = unit==u, onClick = { unit=u }, label = { Text(u.name) }, modifier = Modifier.padding(2.dp)) } }
                    Text("مثال: 1/10/2026 كل 10 أيام = 1/10 ثم 11/10 ثم 21/10 ثم 31/10 ثم 10/11", style = MaterialTheme.typography.bodySmall)
                }
                Row {
                    FilterChip(selected = endType==EndType.NEVER, onClick = { endType=EndType.NEVER }, label = { Text("بدون نهاية") })
                    Spacer(Modifier.width(4.dp))
                    FilterChip(selected = endType==EndType.AFTER_COUNT, onClick = { endType=EndType.AFTER_COUNT }, label = { Text("بعد عدد") })
                }
                if (endType==EndType.AFTER_COUNT) OutlinedTextField(value = endCountText, onValueChange = { endCountText = it }, label = { Text("عدد التكرارات") })
            }
        },
        confirmButton = {
            Button(onClick = {
                val interval = intervalText.toIntOrNull() ?: 1
                val count = endCountText.toIntOrNull()
                onSave(Reminder(title = title.ifBlank { "تذكير" }, startDateTimeMillis = System.currentTimeMillis()+60000, repeatEnabled = repeatEnabled, repeatInterval = interval, repeatUnit = unit, endType = endType, endCount = count))
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
