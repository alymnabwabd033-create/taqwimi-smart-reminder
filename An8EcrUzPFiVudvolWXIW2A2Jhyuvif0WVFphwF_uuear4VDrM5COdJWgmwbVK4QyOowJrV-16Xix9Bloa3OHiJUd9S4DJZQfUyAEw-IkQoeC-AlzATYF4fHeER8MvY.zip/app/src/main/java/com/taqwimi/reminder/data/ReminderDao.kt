
package com.taqwimi.reminder.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow
@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY startDateTimeMillis ASC")
    fun getAllFlow(): Flow<List<Reminder>>
    @Query("SELECT * FROM reminders WHERE isActive = 1")
    suspend fun getActive(): List<Reminder>
    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getById(id: Long): Reminder?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(reminder: Reminder): Long
    @Delete
    suspend fun delete(reminder: Reminder)
    @Query("SELECT * FROM reminders WHERE title LIKE '%' || :q || '%'")
    fun search(q: String): Flow<List<Reminder>>
    @Query("UPDATE reminders SET isActive = :active WHERE id = :id")
    suspend fun setActive(id: Long, active: Boolean)
}
