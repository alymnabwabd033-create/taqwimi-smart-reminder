
package com.taqwimi.reminder
import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
class TaqwimiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }
}
