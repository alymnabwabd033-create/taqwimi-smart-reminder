
package com.taqwimi.reminder.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.taqwimi.reminder.data.Reminder
import com.taqwimi.reminder.data.ReminderDao
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
class ReminderViewModel(private val dao: ReminderDao) : ViewModel() {
    private val _reminders = MutableStateFlow<List<Reminder>>(emptyList())
    val reminders: StateFlow<List<Reminder>> = _reminders
    init { viewModelScope.launch { dao.getAllFlow().collect { _reminders.value = it } } }
    fun search(q: String) { viewModelScope.launch { if (q.isBlank()) dao.getAllFlow().collect { _reminders.value = it } else dao.search(q).collect { _reminders.value = it } } }
    fun add(r: Reminder) = viewModelScope.launch { dao.upsert(r) }
    fun delete(r: Reminder) = viewModelScope.launch { dao.delete(r) }
    fun toggleActive(r: Reminder) = viewModelScope.launch { dao.setActive(r.id, !r.isActive) }
}
class ReminderViewModelFactory(private val dao: ReminderDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ReminderViewModel(dao) as T
}
