
package com.taqwimi.reminder.notifications
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.taqwimi.reminder.data.AppDatabase
import com.taqwimi.reminder.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1)
        val title = intent.getStringExtra("title") ?: "تذكير"
        val desc = intent.getStringExtra("desc") ?: ""
        val isSnooze = intent.getBooleanExtra("isSnooze", false)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "taqwimi_reminders"
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(channelId, "تذكيرات تقويمي", NotificationManager.IMPORTANCE_HIGH))
        }
        val doneIntent = Intent(context, ActionReceiver::class.java).apply { putExtra("id", id); putExtra("action", "done") }
        val donePi = PendingIntent.getBroadcast(context, (id+1).toInt(), doneIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snooze5 = PendingIntent.getBroadcast(context, (id+2).toInt(), Intent(context, ActionReceiver::class.java).apply { putExtra("id", id); putExtra("action", "snooze"); putExtra("minutes", 5); putExtra("title", title) }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snooze15 = PendingIntent.getBroadcast(context, (id+3).toInt(), Intent(context, ActionReceiver::class.java).apply { putExtra("id", id); putExtra("action", "snooze"); putExtra("minutes", 15); putExtra("title", title) }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snooze60 = PendingIntent.getBroadcast(context, (id+4).toInt(), Intent(context, ActionReceiver::class.java).apply { putExtra("id", id); putExtra("action", "snooze"); putExtra("minutes", 60); putExtra("title", title) }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notif = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(desc.ifEmpty { "حان وقت التذكير" })
            .setPriority(NotificationCompat.PRIORITY_MAX).setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .addAction(0, "تم", donePi)
            .addAction(0, "غفوة 5د", snooze5)
            .addAction(0, "غفوة 15د", snooze15)
            .addAction(0, "ساعة", snooze60)
            .build()
        nm.notify(id.toInt(), notif)
        if (!isSnooze && id != -1L) {
            CoroutineScope(Dispatchers.IO).launch {
                val r = AppDatabase.get(context).reminderDao().getById(id)
                if (r != null && r.isActive && r.repeatEnabled) AlarmScheduler.schedule(context, r)
            }
        }
    }
}
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1)
        val action = intent.getStringExtra("action")
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(id.toInt())
        if (action == "snooze") {
            val minutes = intent.getIntExtra("minutes", 5)
            val title = intent.getStringExtra("title") ?: "تذكير"
            AlarmScheduler.snooze(context, id, title, minutes)
        }
    }
}
