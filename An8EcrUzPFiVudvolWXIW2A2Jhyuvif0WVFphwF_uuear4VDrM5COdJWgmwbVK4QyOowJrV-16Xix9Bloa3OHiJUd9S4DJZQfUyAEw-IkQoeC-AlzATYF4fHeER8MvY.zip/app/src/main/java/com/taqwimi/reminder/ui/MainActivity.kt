
package com.taqwimi.reminder.ui
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.taqwimi.reminder.data.AppDatabase
import com.taqwimi.reminder.engine.RecurrenceEngine
import com.taqwimi.reminder.ui.theme.TaqwimiTheme
import java.time.format.DateTimeFormatter
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).reminderDao()
        setContent {
            TaqwimiTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val vm: ReminderViewModel = viewModel(factory = ReminderViewModelFactory(dao))
                    val reminders by vm.reminders.collectAsState()
                    var showAdd by remember { mutableStateOf(false) }
                    var query by remember { mutableStateOf("") }
                    Scaffold(topBar = { TopAppBar(title = { Text("تقويمي - التذكير الذكي") }) }, floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+") } }) { pad ->
                        Column(Modifier.padding(pad).padding(16.dp)) {
                            OutlinedTextField(value = query, onValueChange = { query = it; vm.search(it) }, label = { Text("بحث...") }, modifier = Modifier.fillMaxWidth())
                            LazyColumn {
                                items(reminders) { r ->
                                    val next = remember(r) { RecurrenceEngine.nextOccurrence(r) }
                                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text(r.title, style = MaterialTheme.typography.titleMedium)
                                            Text("التالي: ${next?.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")) ?: "-"}")
                                            Text("كل ${r.repeatInterval} ${r.repeatUnit} - ${r.endType}")
                                            Row {
                                                TextButton(onClick = { vm.toggleActive(r) }) { Text(if(r.isActive) "ايقاف" else "استئناف") }
                                                TextButton(onClick = { vm.delete(r) }) { Text("حذف") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (showAdd) AddReminderDialog(onDismiss = { showAdd = false }, onSave = { vm.add(it); showAdd = false })
                    }
                }
            }
        }
    }
}
