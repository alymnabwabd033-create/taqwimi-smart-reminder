
package com.taqwimi.reminder.data
import androidx.room.Entity
import androidx.room.PrimaryKey
enum class RepeatUnit { DAY, WEEK, MONTH, YEAR }
enum class EndType { NEVER, UNTIL_DATE, AFTER_COUNT }
enum class Priority { LOW, MEDIUM, HIGH }
enum class Category { WORK, PERSONAL, HEALTH, STUDY, OTHER }
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val startDateTimeMillis: Long,
    val repeatEnabled: Boolean = false,
    val repeatInterval: Int = 1,
    val repeatUnit: RepeatUnit = RepeatUnit.DAY,
    val endType: EndType = EndType.NEVER,
    val endDateMillis: Long? = null,
    val endCount: Int? = null,
    val isActive: Boolean = true,
    val priority: Priority = Priority.MEDIUM,
    val category: Category = Category.PERSONAL,
    val createdAt: Long = System.currentTimeMillis()
)
