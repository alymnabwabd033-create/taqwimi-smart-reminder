
# تقويمي - التذكير الذكي

تطبيق Android اصلي كامل RTL.

## المحرك
RecurrenceEngine يحسب: start + n * interval بوحدة DAY/WEEK/MONTH/YEAR
يدعم كل 10 ايام: 1/10 -> 11/10 -> 21/10 -> 31/10 -> 10/11

## البناء
./gradlew assembleDebug
الملف: app/build/outputs/apk/debug/app-debug.apk
